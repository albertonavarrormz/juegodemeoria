import UIKit

for n in 0...100
{
    if n%5==0{
        print("\(n) Bingo!!!")
    }
    if n%2==0{
        print("\(n) es par!!!")
    }
    else{
        print("\(n) es impar!!!")
    }
    switch n{
    case 30...40: print("\(n) Viva Swift!!!")
    break
    default:
        print("")
    }
}
